const box = document.querySelector('.box');
